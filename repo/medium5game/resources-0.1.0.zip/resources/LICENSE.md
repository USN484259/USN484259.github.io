* 请注意，若资源未标明许可协议，则应视为“独有”(proprietary)


| 资源 | 作者/版权方 | 来源 | 许可协议(如果有) | 对原图的修改 |
| ---- | ---- | ---- | ---- | ---- |
| wqy-zenhei.ttc | 文泉驿 | http://wenq.org | GPLv2 ||
| NotoColorEmoji.ttf | Google | https://github.com/googlefonts/noto-emoji | Apache 2.0 ||
| entity.cangqiong.png | 北京福托科技开发有限责任公司 | https://t.bilibili.com/155082623291940730 || 裁剪，去除背景 |
| entity.chiyu.png | 北京福托科技开发有限责任公司 | https://t.bilibili.com/155082623291940730 || 裁剪，去除背景 |
| entity.haiyi.png | 北京福托科技开发有限责任公司 | https://t.bilibili.com/155082623291940730 || 裁剪，去除背景 |
| entity.shian.png | 北京福托科技开发有限责任公司 | https://t.bilibili.com/155082623291940730 || 裁剪，去除背景 |
| entity.stardust.png | 北京福托科技开发有限责任公司 | https://t.bilibili.com/155082623291940730 || 裁剪，去除背景 |
| entity.toolman.png | USN484259 || CC-BY-4.0 ||
| icon.arrow.png | OnlineWebFonts | https://www.onlinewebfonts.com | CC-BY-3.0 | 格式转换 |
| icon.cangqiong.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| icon.chiyu.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| icon.crosshair.png | OnlineWebFonts | https://www.onlinewebfonts.com | CC-BY-3.0 | 格式转换 |
| icon.haiyi.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| icon.shian.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| icon.stardust.png | 北京福托科技开发有限责任公司 | https://t.bilibili.com/692694120822472745 || 拼接，裁剪，去除背景 |
| icon.toolman.png | USN484259 || CC-BY-4.0 ||
| illustration.chiyu.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| illustration.haiyi.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| illustration.shian.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| illustration.stardust.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| item.haiyi.jellyfish.png | 北京福托科技开发有限责任公司 | https://t.bilibili.com/510530878303525506 || 裁剪，去除背景 |
| item.haiyi.wand.png | 北京福托科技开发有限责任公司 | https://t.bilibili.com/510530878303525506 || 裁剪，去除背景 |
| item.shian.apple.png | Google | Noto Emoji Food Drink Icons | Apache 2.0 ||
| item.shian.yankai.png | 北京福托科技开发有限责任公司 | https://t.bilibili.com/510530878303525506 || 裁剪，去除背景 |
| item.stardust.lance.png | 北京福托科技开发有限责任公司 | https://t.bilibili.com/510530878303525506 || 裁剪，去除背景，去除前景，补色 |
| item.stardust.mirror.png | 北京福托科技开发有限责任公司 | https://t.bilibili.com/510530878303525506 || 裁剪，去除背景，去除前景，拼接 |
| item.stardust.prism.png | Kieed | https://t.bilibili.com/63386643479415654 || 裁剪，去除背景 |
| menu.background.png | Kieed | https://t.bilibili.com/285555152696424104 || 裁剪 |
| name.cangqiong.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| name.chiyu.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| name.haiyi.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| name.shian.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
| name.stardust.png | 北京福托科技开发有限责任公司 | https://quadimension.taobao.com/ || 裁剪，去除背景 |
